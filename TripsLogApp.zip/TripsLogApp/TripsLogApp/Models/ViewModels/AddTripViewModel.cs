﻿// Models/ViewModels/AddTripViewModel.cs

using System;
using System.ComponentModel.DataAnnotations;

namespace TripsLogApp.Models.ViewModels
{
    public class AddTripViewModel
    {
        [Required(ErrorMessage = "Destination is required")]
        public string? Destination { get; set; }

        // Accommodations field is optional
        public string? Accommodations { get; set; }

        [Required(ErrorMessage = "Start Date is required")]
        [DataType(DataType.Date)]
        public DateTime StartDate { get; set; }

        [Required(ErrorMessage = "End Date is required")]
        [DataType(DataType.Date)]
        public DateTime EndDate { get; set; }
    }
}
