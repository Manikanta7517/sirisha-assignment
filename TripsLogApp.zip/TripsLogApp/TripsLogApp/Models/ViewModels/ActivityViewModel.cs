﻿
namespace TripsLogApp.Models.ViewModels
{
    public class ActivityViewModel
    {
        public string ActivityDetails { get; set; }
        public ActivityViewModel()
        {
            ActivityDetails = string.Empty; 
        }
    }
}

