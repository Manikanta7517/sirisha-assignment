﻿// Models/ViewModels/AccommodationViewModel.cs
namespace TripsLogApp.Models.ViewModels
{
    public class AccommodationViewModel
    {
        public string AccommodationDetails { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }

        public AccommodationViewModel()
        {
            AccommodationDetails = string.Empty;
            Email = string.Empty;
            Phone = string.Empty;
        }
    }
}
