﻿using System;

namespace TripsLogApp.Models
{
    public class Trip
    {
        public int Id { get; set; }
        public string Destination { get; set; } = string.Empty; 
        public DateTime StartDate { get; set; }

    }
}



