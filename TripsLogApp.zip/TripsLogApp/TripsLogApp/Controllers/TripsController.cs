﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using TripsLogApp.Models.ViewModels;

namespace TripsLogApp.Controllers
{
    public class TripsController : Controller
    {
        [HttpGet]
        public IActionResult AddTripAccommodation()
        {
            // Retrieve data from TempData and deserialize it
            var addTripDataJson = TempData["AddTripData"] as string;

            // Check if addTripDataJson is not null
            if (string.IsNullOrEmpty(addTripDataJson))
            {
                // Redirect to step 1 if data is not available
                return RedirectToAction("AddTripDestinations");
            }

            // Deserialize the data and check for null
            var tempData = JsonConvert.DeserializeObject<Tuple<AddTripViewModel, string>>(addTripDataJson);

            if (tempData == null || tempData.Item1 == null || string.IsNullOrEmpty(tempData.Item1.Accommodations))
            {
                // Redirect to step 1 if Accommodations is not provided
                return RedirectToAction("AddTripDestinations");
            }

            // Pass the data to the view
            ViewData["AccommodationsName"] = tempData.Item1.Accommodations;
            return View(new AccommodationViewModel());
        }

        [HttpPost]
        public IActionResult AddTripAccommodation(AccommodationViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            // Save data to TempData to pass to the next step
            TempData["AccommodationData"] = JsonConvert.SerializeObject(model);

            // Redirect to the next step
            return RedirectToAction("AddTripActivities");
        }

        [HttpGet]
        public IActionResult AddTripActivities()
        {
            // Retrieve data from TempData and deserialize it
            var addTripDataJson = TempData["AddTripData"] as string;
            var accommodationDataJson = TempData["AccommodationData"] as string;

            // Check if data is provided, otherwise redirect to the previous step
            if (string.IsNullOrEmpty(addTripDataJson) || string.IsNullOrEmpty(accommodationDataJson))
            {
                return RedirectToAction("AddTripAccommodation");
            }

            var tripData = JsonConvert.DeserializeObject<AddTripViewModel>(addTripDataJson);
            var accommodationData = JsonConvert.DeserializeObject<AccommodationViewModel>(accommodationDataJson);

            // Pass the data to the view
            ViewData["TripData"] = tripData;
            ViewData["AccommodationData"] = accommodationData;

            return View();
        }

        [HttpPost]
        public IActionResult AddTripActivities(ActivityViewModel model)
        {
            // Similar logic for handling AddTripActivities POST
            return RedirectToAction("Index");
        }
    }
}
